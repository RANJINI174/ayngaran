<?php

namespace App\Http\Controllers;
use App\Models\Branch;
use App\Models\Director;
use App\Models\Relationship;
use App\Models\Pincode;
use App\Models\Designation;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class DirectorController extends Controller
{
    public function index()
    {
        try {
            $directors = User::where('user_type','director')->orderby('id','asc')->get();
            return view('team_manage.directors.index', compact('directors'));
        } catch (\Exception $e) {
            return back()->with(['error' => $e->getMessage()])->withInput();
        }
    }
    public function create()
    {
        try {
            $count = User::where('user_type','director')->get()->count();
            $branch = Branch::where('status',1)->get();
            $relations = Relationship::where('status',1)->get();
            $designation = Designation::where('status',1)->get();
            return view('team_manage.directors.add', compact('count','branch','relations','designation'));
        } catch (\Exception $e) {
            return back()->with(['error' => $e->getMessage()])->withInput();
        }
    }
    public function store(Request $request)
    {
        $validate = $request->validate([
            'reference_code' => 'required',
            'name' => 'required',
            'password' => 'required',
            'designation_id' => 'required',
            'team_name'  => 'required',
            'father_husband_name' => 'required',
            'branch_id' => 'required',
            'join_date' => 'required',
            // 'introduced_by' => 'required',
            'marrital_status' => 'required',
            // 'wedding_date' => 'required',
            'nominee_name' => 'required',
            'relationship' => 'required',
            'nominee_mobile' => 'required|numeric|digits:10',
            'email' => 'required|email',
            'mobile_no' => 'required|numeric|digits:10',
            'address' => 'required',
            'dob' => 'required|date|before_or_equal:today',
        ]);
        
        $director = new User();
        
        if($request->password)
        {
            $password = Hash::make($request->password);
            $encrypt_password = encrypt($request->password);
        }
        
        //  if($request->introduced_by == 'thired_party')
        // {
        //     $validate = $request->validate([
        //     'thired_party_name' => 'required',
        //     'thired_party_mobile' => 'required|numeric|digits:10',
           
        // ]);
        // }else{
        //   $validate = $request->validate([
        //     'introducer' => 'required',
            
        // ]);  
        // }
          $check_mail = User::where('email',$request->email)->get()->count();
        if($check_mail > 0)
        {
           return response()->json(['status' => false, 'message' => 'Email Already Exist!']); 
        }
        
         $check_mobile = User::where('mobile_no',$request->mobile_no)->get()->count();
         
        if($check_mobile > 0)
        {
           return response()->json(['status' => false, 'message' => 'Mobile No Already Exist!']); 
        }
        
       
        
        $director->reference_code = $request->reference_code;
        $director->name = $request->name;
        $director->password = $password;
        $director->encrypt_password = $encrypt_password;
        $director->user_type = 'director';
        $director->designation_id = $request->designation_id;
        $director->team_name = $request->team_name;
        $director->father_husband_name = $request->father_husband_name;
        $director->branch_id = $request->branch_id;
        $director->join_date = $request->join_date;
        $director->marrital_status = $request->marrital_status;
        $director->email = $request->email;
        $director->wedding_date = $request->wedding_date;
        $director->nominee_name = $request->nominee_name;
        $director->nominee_mobile = $request->nominee_mobile;
        $director->address = $request->address;
        $director->mobile_no = $request->mobile_no;
        $director->alternate_mobile = $request->alternate_mobile;
        $director->dob = $request->dob;
        $director->gender = $request->gender;
        $director->pincode = $request->pincode;
        $director->area = $request->area;
        $director->city_id = $request->city_id;
        $director->state_id = $request->state_id;
        $director->country_id = $request->country_id;
        $director->relationship = $request->relationship;
        $director->bank_name = $request->bank_name;
        $director->account_no = $request->account_no;
        $director->ifsc_code = $request->ifsc_code;
        $director->bank_branch = $request->bank_branch;
        $director->introduced_by = $request->introduced_by;
        $director->introducer_id = $request->introducer;
        $director->thired_party_name = $request->thired_party_name;
        $director->thired_party_mobile = $request->thired_party_mobile;
        $director->status = $request->status;
       
        $insert =  $director->save();
        
        if($insert)
        {
         return response()->json(['status' => true, 'message' => 'Director Created Successfully!']);   
        }
        else{
         return response()->json(['status' => false, 'message' => 'Director Creation Failed!']);
        }
        
    }
    
    public function introducer_list($id)
    {
        $director =User::where('designation_id',$id)->select('id','name')->get();
        return response()->json(['status' => true, 'data' => $director], 200);
    }
    
     public function introducerid_list($id)
    {
        $director =User::where('id',$id)->select('reference_code')->first();
       
        return response()->json(['status' => true, 'data' => $director], 200);
    }

    public function edit($id)
    {
        if (!empty($id)) {
            $introducer_name = '';
            $introducer_id = '';
            $director =User::where('user_type','director')->where('id', $id)->first();
            if($director->introduced_by != 'thired_party')
            {
              $introducer_name = User::where('designation_id',$director->introduced_by)->get();
              $introducer_id = User::where('id',$director->introducer_id)->value('reference_code');
            }
            $branch = Branch::where('status',1)->get();
            $relations = Relationship::where('status',1)->get();
            $areas  = Pincode::where('pincode', $director->pincode)->get();
            $state  = Pincode::select('id', 'state')->where('pincode', $director->pincode)->first();
            $city  = Pincode::select('id', 'city')->where('pincode', $director->pincode)->first();
            $designation = Designation::where('status',1)->get();
            // dd($state);
            return view('team_manage.directors.edit', compact('director', 'areas', 'state', 'city','branch','relations','designation','introducer_id','introducer_name'));
        }
        return response()->json(['status' => false, 'message' => 'Director not found!']);
    }

    public function update(Request $request, $id)
    {
        $validate = $request->validate([
            'reference_code' => 'required',
            'name' => 'required',
            'email' => 'required|email',
            // 'password' => 'required',
            'designation_id' => 'required',
            'team_name'  => 'required',
            'father_husband_name' => 'required',
            'branch_id' => 'required',
            'join_date' => 'required',
            // 'introduced_by' => 'required',
            'marrital_status' => 'required',
            // 'wedding_date' => 'required',
            'nominee_name' => 'required',
            'relationship' => 'required',
            'nominee_mobile' => 'required|numeric|digits:10',
            'mobile_no' => 'required|numeric|digits:10',
            'address' => 'required',
            'dob' => 'required|date|before_or_equal:today',
        ]);
        
        
      
        $data = [];
        if($request->password)
        {
            $password = Hash::make($request->password);
            $encrypt_password = encrypt($request->password);
        }
        if($request->introduced_by == 'thired_party')
        {
        //     $validate = $request->validate([
        //     'thired_party_name' => 'required',
        //     'thired_party_mobile' => 'required|numeric|digits:10',
           
        // ]);
            $data['introducer_id'] = 0;
            $data['thired_party_name'] = $request->thired_party_name;
            $data['thired_party_mobile'] = $request->thired_party_mobile;
        }else{
        //     $validate = $request->validate([
        //     'introducer' => 'required',
        //  ]);
        
        if($request->introduced_by != '')
        {
            $data['introducer_id'] = $request->introducer;
        }else{
            
            $data['introducer_id'] = 0;
        }
            $data['thired_party_name'] = null;
            $data['thired_party_mobile'] = null;
        }
        
         $check_mail = User::where('email',$request->email)->where('id','!=',$id)->get()->count();
        if($check_mail > 0)
        {
           return response()->json(['status' => false, 'message' => 'Email Already Exist!']); 
        }
        
         $check_mobile = User::where('mobile_no',$request->mobile_no)->where('id','!=',$id)->get()->count();
         
        if($check_mobile > 0)
        {
           return response()->json(['status' => false, 'message' => 'Mobile No Already Exist!']); 
        }
        
        $data['reference_code'] = $request->reference_code;
        $data['name'] = $request->name;
        // $data['password'] = $password;
        // $data['encrypt_password'] = $encrypt_password;
        // $data['user_type'] = 'director';
        $data['designation_id'] = $request->designation_id;
        $data['team_name'] = $request->team_name;
        $data['father_husband_name'] = $request->father_husband_name;
        $data['branch_id'] = $request->branch_id;
        $data['join_date'] = $request->join_date;
        $data['marrital_status'] = $request->marrital_status;
        $data['email'] = $request->email;
        $data['wedding_date'] = $request->wedding_date;
        $data['nominee_name'] = $request->nominee_name;
        $data['nominee_mobile'] = $request->nominee_mobile;
        $data['address'] = $request->address;
        $data['mobile_no'] = $request->mobile_no;
        $data['alternate_mobile'] = $request->alternate_mobile;
        $data['dob'] = $request->dob;
        $data['gender'] = $request->gender;
        $data['pincode'] = $request->pincode;
        $data['area'] = $request->area;
        $data['city_id'] = $request->city_id;
        $data['state_id'] = $request->state_id;
        $data['country_id'] = $request->country_id;
        $data['bank_name'] = $request->bank_name;
        $data['account_no'] = $request->account_no;
        $data['ifsc_code'] = $request->ifsc_code;
        $data['bank_branch'] = $request->bank_branch;
        $data['introduced_by'] = $request->introduced_by;
        $data['status'] = $request->status;
        $data['relationship'] = $request->relationship;
         
        $update = User::where('id', $id)->update($data);
        if($update)
        {
        return response()->json(['status' => true, 'message' => 'Director Updated Successfully!']);    
        }else{
         return response()->json(['status' => false, 'message' => 'Director Updation Failed!']);
        }
        
    }
    public function delete($id)
    {
        if (!empty($id)) {
            $director = User::where('id', $id)->delete();
            if($director)
            {
              return response()->json(['status' => true, 'message' => 'Director Deleted Successfully!']);  
            }else{
              return response()->json(['status' => false, 'message' => 'Director Deleted Failed!']);
            }
            
        }
    }
}
