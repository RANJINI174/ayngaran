<?php

namespace App\Http\Controllers;
use App\Models\Branch;
use App\Models\Director;
use App\Models\Relationship;
use App\Models\Designation;
use App\Models\User;
use Illuminate\Http\Request;
use App\Models\MarketingExecutive;
use App\Models\Pincode;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class MarketingExecutiveController extends Controller
{
    public function index()
    {
        try {
            $marketing_executives = User::where('user_type','marketing_executive')->orderby('id','asc')->get();
            return view('team_manage.marketing_executive.index', compact('marketing_executives'));
        } catch (\Exception $e) {
            return back()->with(['error' => $e->getMessage()])->withInput();
        }
    }
    public function create()
    {
        try {
            $count = User::where('user_type','marketing_executive')->get()->count();
            $director = User::where('user_type','director')->where('status',1)->get();
            $marketing_manager = User::where('user_type','marketing-manager')->where('status',1)->get();
            $marketing_supervisor = User::where('user_type','marketing-supervisor')->where('status',1)->get();
            $branch = Branch::where('status',1)->get();
            $relations = Relationship::where('status',1)->get();
            $designation = Designation::where('status',1)->get();
            return view('team_manage.marketing_executive.add', compact('count','branch','relations','designation','director','marketing_manager','marketing_supervisor'));
        } catch (\Exception $e) {
            return back()->with(['error' => $e->getMessage()])->withInput();
        }
    }
    public function store(Request $request)
    {
        
        $validate = $request->validate([
            'reference_code' => 'required',
            'name' => 'required',
             'password' => 'required',
            // 'team_name'  => 'required',
            'father_husband_name' => 'required',
            'designation_id' => 'required',
            'branch_id' => 'required',
            'join_date' => 'required',
            // 'introduced_by' => 'required',
            'marrital_status' => 'required',
            // 'wedding_date' => 'required',
            'nominee_name' => 'required',
            'relationship' => 'required',
            'nominee_mobile' => 'required|numeric|digits:10',
            'email' => 'required|email',
            'mobile_no' => 'required|numeric|digits:10',
            'address' => 'required',
            'dob' => 'required|date|before_or_equal:today',
        ]);
        
        $m_executive = new User();
        
        if($request->password)
        {
            $password = Hash::make($request->password);
            $encrypt_password = encrypt($request->password);
        }
        
        //  if($request->introduced_by == 'Thired Party')
        // {
        //     $validate = $request->validate([
        //     'thired_party_name' => 'required',
        //     'thired_party_mobile' => 'required|numeric|digits:10',
           
        // ]);
        // }else{
        //   $validate = $request->validate([
        //     'introducer' => 'required',
            
        // ]);  
        // }
        
        $check_mail = User::where('email',$request->email)->get()->count();
        if($check_mail > 0)
        {
           return response()->json(['status' => false, 'message' => 'Email Already Exist!']); 
        }
        
         $check_mobile = User::where('mobile_no',$request->mobile_no)->get()->count();
         
        if($check_mobile > 0)
        {
           return response()->json(['status' => false, 'message' => 'Mobile No Already Exist!']); 
        }
        
        
        
        $m_executive->reference_code = $request->reference_code;
        $m_executive->name = $request->name;
        $m_executive->password = $password;
        $m_executive->encrypt_password = $encrypt_password;
        $m_executive->user_type = 'marketing_executive';
        $m_executive->designation_id = $request->designation_id;
        // $m_executive->team_name = $request->team_name;
        $m_executive->father_husband_name = $request->father_husband_name;
        $m_executive->branch_id = $request->branch_id;
        $m_executive->join_date = $request->join_date;
        $m_executive->director_id = $request->director_id;
        $m_executive->marketing_manager_id = $request->marketing_manager_id;
        $m_executive->marketing_supervisor_id = $request->marketing_supervisor_id;
        $m_executive->marrital_status = $request->marrital_status;
        $m_executive->email = $request->email;
        $m_executive->wedding_date = $request->wedding_date;
        $m_executive->nominee_name = $request->nominee_name;
        $m_executive->nominee_mobile = $request->nominee_mobile;
        $m_executive->address = $request->address;
        $m_executive->mobile_no = $request->mobile_no;
        $m_executive->alternate_mobile = $request->alternate_mobile;
        $m_executive->dob = $request->dob;
        $m_executive->gender = $request->gender;
        $m_executive->pincode = $request->pincode;
        $m_executive->area = $request->area;
        $m_executive->city_id = $request->city_id;
        $m_executive->state_id = $request->state_id;
        $m_executive->country_id = $request->country_id;
        $m_executive->relationship = $request->relationship;
        $m_executive->bank_name = $request->bank_name;
        $m_executive->account_no = $request->account_no;
        $m_executive->ifsc_code = $request->ifsc_code;
        $m_executive->bank_branch = $request->bank_branch;
        $m_executive->introduced_by = $request->introduced_by;
        $m_executive->introducer_id = $request->introducer;
        $m_executive->thired_party_name = $request->thired_party_name;
        $m_executive->thired_party_mobile = $request->thired_party_mobile;
        $m_executive->status = $request->status;
       
        $insert =  $m_executive->save();
        
        if($insert)
        {
         return response()->json(['status' => true, 'message' => 'Marketing Executive Created Successfully!']);   
        }
        else{
         return response()->json(['status' => true, 'message' => 'Marketing Executive Created Successfully!']);
        }
        
    }
    public function edit($id)
    {
        if (!empty($id)) {
            $introducer_name = '';
            $introducer_id = '';
            $marketing_executive =User::where('user_type','marketing_executive')->where('id', $id)->first();
            if($marketing_executive->introduced_by != 'thired_party')
            {
              $introducer_name = User::where('designation_id',$marketing_executive->introduced_by)->get();
              $introducer_id = User::where('id',$marketing_executive->introducer_id)->value('reference_code');
            }
            $director = User::where('user_type','director')->where('status',1)->get();
            $marketing_manager = User::where('user_type','marketing-manager')->where('status',1)->get();
            $marketing_supervisor = User::where('user_type','marketing-supervisor')->where('status',1)->get();
            $branch = Branch::where('status',1)->get();
            $relations = Relationship::where('status',1)->get();
            $areas  = Pincode::where('pincode', $marketing_executive->pincode)->get();
            $state  = Pincode::select('id', 'state')->where('pincode', $marketing_executive->pincode)->first();
            $city  = Pincode::select('id', 'city')->where('pincode', $marketing_executive->pincode)->first();
            $designation = Designation::where('status',1)->get();
            // dd($state);
            return view('team_manage.marketing_executive.edit', compact('marketing_executive','director', 'areas', 'state', 'city','branch','relations','designation','director','marketing_manager',
            'marketing_supervisor','introducer_id','introducer_name'));
            
           
        }
        return response()->json(['status' => false, 'message' => 'Marketing Executive not found!']);
    }
    public function update(Request $request, $id)
    {
        $validate = $request->validate([
            'reference_code' => 'required',
            'name' => 'required',
             // 'password' => 'required',
            // 'team_name'  => 'required',
            'father_husband_name' => 'required',
            'branch_id' => 'required',
            'join_date' => 'required',
            // 'introduced_by' => 'required',
            'designation_id' => 'required',
            'marrital_status' => 'required',
            // 'wedding_date' => 'required',
            'nominee_name' => 'required',
            'relationship' => 'required',
            'nominee_mobile' => 'required|numeric|digits:10',
            'email' => 'required|email',
            'mobile_no' => 'required|numeric|digits:10',
            'address' => 'required',
            'dob' => 'required|date|before_or_equal:today',
        ]);
        
        $data = [];
        if($request->password)
        {
            $password = Hash::make($request->password);
            $encrypt_password = encrypt($request->password);
        }
       if($request->introduced_by == 'Thired Party')
        {
        //     $validate = $request->validate([
        //     'thired_party_name' => 'required',
        //     'thired_party_mobile' => 'required|numeric|digits:10',
           
        // ]);
            $data['introducer_id'] = 0;
            $data['thired_party_name'] = $request->thired_party_name;
            $data['thired_party_mobile'] = $request->thired_party_mobile;
        }else{
        //     $validate = $request->validate([
        //     'introducer' => 'required',
        //  ]);
        
        if($request->introduced_by != '')
        {
            $data['introducer_id'] = $request->introducer;
        }else{
            
            $data['introducer_id'] = 0;
        }
            $data['thired_party_name'] = null;
            $data['thired_party_mobile'] = null;
        }
        
        
        $check_mail = User::where('email',$request->email)->where('id','!=',$id)->get()->count();
        if($check_mail > 0)
        {
           return response()->json(['status' => false, 'message' => 'Email Already Exist!']); 
        }
        
         $check_mobile = User::where('mobile_no',$request->mobile_no)->where('id','!=',$id)->get()->count();
         
        if($check_mobile > 0)
        {
           return response()->json(['status' => false, 'message' => 'Mobile No Already Exist!']); 
        }
        
        $data['reference_code'] = $request->reference_code;
        $data['name'] = $request->name;
        // $data['password'] = $password;
        // $data['encrypt_password'] = $encrypt_password;
        // $data['user_type'] = 'marketing_executive';
        $data['director_id'] = $request->director_id;
        $data['marketing_manager_id'] = $request->marketing_manager_id;
        $data['marketing_supervisor_id'] = $request->marketing_supervisor_id;
        $data['designation_id'] = $request->designation_id;
        // $data['team_name'] = $request->team_name;
        $data['father_husband_name'] = $request->father_husband_name;
        $data['branch_id'] = $request->branch_id;
        $data['join_date'] = $request->join_date;
        $data['marrital_status'] = $request->marrital_status;
        $data['email'] = $request->email;
        $data['wedding_date'] = $request->wedding_date;
        $data['nominee_name'] = $request->nominee_name;
        $data['nominee_mobile'] = $request->nominee_mobile;
        $data['address'] = $request->address;
        $data['mobile_no'] = $request->mobile_no;
        $data['alternate_mobile'] = $request->alternate_mobile;
        $data['dob'] = $request->dob;
        $data['gender'] = $request->gender;
        $data['pincode'] = $request->pincode;
        $data['area'] = $request->area;
        $data['city_id'] = $request->city_id;
        $data['state_id'] = $request->state_id;
        $data['country_id'] = $request->country_id;
        $data['bank_name'] = $request->bank_name;
        $data['account_no'] = $request->account_no;
        $data['ifsc_code'] = $request->ifsc_code;
        $data['bank_branch'] = $request->bank_branch;
        $data['introduced_by'] = $request->introduced_by;
        $data['status'] = $request->status;
        $data['relationship'] = $request->relationship;
         
        $update = User::where('id', $id)->update($data);
        if($update)
        {
        return response()->json(['status' => true, 'message' => 'Marketing Executive Updated Successfully!']);    
        }else{
         return response()->json(['status' => true, 'message' => 'Marketing Executive Updation Failed!']);
        }
    }
    public function delete($id)
    {
        if (!empty($id)) {
            $marketing_executive = User::where('id', $id)->delete();
            if($marketing_executive)
            {
             return response()->json(['status' => true, 'message' => 'Marketing Executive Deleted Success!']);   
            }else{
             return response()->json(['status' => false, 'message' => 'Marketing Executive Deleted Failed!']);
            }
            
        }
    }
}
