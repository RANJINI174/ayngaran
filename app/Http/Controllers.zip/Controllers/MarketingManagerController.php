<?php

namespace App\Http\Controllers;

use App\Models\Branch;
use App\Models\Designation;
use App\Models\Director;
use Illuminate\Http\Request;
use App\Models\MarketingManager;
use App\Models\Pincode;
use App\Models\Relationship;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

class MarketingManagerController extends Controller
{
    public function index()
    {
        try {
            $marketing_managers = User::where('user_type', 'marketing-manager')->get();
            return view('team_manage.marketing_manager.index', compact('marketing_managers'));
        } catch (\Exception $e) {
            return back()->with(['error' => $e->getMessage()])->withInput();
        }
    }
    public function create()
    {
        try {
            $count = User::where('user_type', 'marketing-manager')->get()->count();
            $directors = User::where('user_type', 'director')->get();
            $branch = Branch::where('status', 1)->get();
            $relations = Relationship::where('status', 1)->get();
            $designation = Designation::where('status', 1)->get();
            return view('team_manage.marketing_manager.add', compact('count', 'branch', 'relations', 'designation', 'directors'));
        } catch (\Exception $e) {
            return back()->with(['error' => $e->getMessage()])->withInput();
        }
    }
    public function store(Request $request)
    {
        $request->validate([
            'reference_code' => 'required',
            'director_id' => 'required',
            'name' => 'required',
            'email' => 'required|email',
            'password' => 'required',
            // 'team_name'  => 'required',
            'father_husband_name' => 'required',
            'branch_id' => 'required',
            'join_date' => 'required',
            // 'introduced_by' => 'required',
            'marrital_status' => 'required',
            // 'wedding_date' => 'required',
            // 'gender' => 'required',
            'nominee_name' => 'required',
            'relationship' => 'required',
            'nominee_mobile' => 'required|numeric|digits:10',
            'mobile_no' => 'required|numeric|digits:10',
            'address' => 'required',
            'dob' => 'required|date|before_or_equal:today',
            'designation_id' => 'required',
        ]);
        $m_manager = new User();

        if ($request->password) {
            $password = Hash::make($request->password);
            $encrypt_password = encrypt($request->password);
        }
        
        //  if($request->introduced_by == 'Thired Party')
        // {
        //     $validate = $request->validate([
        //     'thired_party_name' => 'required',
        //     'thired_party_mobile' => 'required|numeric|digits:10',
           
        // ]);
        // }else{
        //   $validate = $request->validate([
        //     'introducer' => 'required',
            
        // ]);  
        // }
        //email and mobile_no
        $check_mail = User::where('email', $request->email)->get()->count();
        if ($check_mail > 0) {
            return response()->json(['status' => false, 'message' => 'Email Already Exist!']);
        }

        $check_mobile = User::where('mobile_no', $request->mobile_no)->get()->count();

        if ($check_mobile > 0) {
            return response()->json(['status' => false, 'message' => 'Mobile No Already Exist!']);
        }

  
        $m_manager->reference_code = $request->reference_code;
        $m_manager->director_id = $request->director_id;
        $m_manager->name = $request->name;
        $m_manager->password = $password;
        $m_manager->encrypt_password = $encrypt_password;
        $m_manager->user_type = 'marketing-manager';
        $m_manager->designation_id = $request->designation_id;
        // $m_manager->team_name = $request->team_name;
        $m_manager->father_husband_name = $request->father_husband_name;
        $m_manager->branch_id = $request->branch_id;
        $m_manager->join_date = $request->join_date;
        $m_manager->marrital_status = $request->marrital_status;
        $m_manager->email = $request->email;
        $m_manager->wedding_date = $request->wedding_date;
        $m_manager->nominee_name = $request->nominee_name;
        $m_manager->relationship = $request->relationship;
        $m_manager->nominee_mobile = $request->nominee_mobile;
        $m_manager->address = $request->address;
        $m_manager->mobile_no = $request->mobile_no;
        $m_manager->alternate_mobile = $request->alternate_mobile;
        $m_manager->dob = $request->dob;
        $m_manager->gender = $request->gender;
        $m_manager->pincode = $request->pincode;
        $m_manager->area = $request->area;
        $m_manager->city_id = $request->city_id;
        $m_manager->state_id = $request->state_id;
        $m_manager->country_id = $request->country_id;
        $m_manager->bank_name = $request->bank_name;
        $m_manager->account_no = $request->account_no;
        $m_manager->ifsc_code = $request->ifsc_code;
        $m_manager->bank_branch = $request->bank_branch;
        $m_manager->introduced_by = $request->introduced_by;
        $m_manager->introducer_id = $request->introducer;
        $m_manager->thired_party_name = $request->thired_party_name;
        $m_manager->thired_party_mobile = $request->thired_party_mobile;
        $m_manager->status = $request->status;
        $insert =  $m_manager->save();

        if ($insert) {
            return response()->json(['status' => true, 'message' => 'Marketing Manager Created Successfully!']);
        } else {
            return response()->json(['status' => false, 'message' => 'Marketing Manager Creation Failed!']);
        }
    }

    public function edit($id)
    {
        if (!empty($id)) {

            $introducer_name = '';
            $introducer_id = '';
            $marketing_manager = User::where('user_type', 'marketing-manager')->where('id', $id)->first();
            if ($marketing_manager->introducer_by != 'thired_party') {
                $introducer_name = User::where('designation_id', $marketing_manager->introduced_by)->get();
                $introducer_id = User::where('id', $marketing_manager->introducer_id)->value('reference_code');
            }
            $directors = User::where('user_type', 'director')->get();
            $branch = Branch::where('status', 1)->get();
            $relations = Relationship::where('status', 1)->get();
            $areas  = Pincode::where('pincode', $marketing_manager->pincode)->get();
            $state  = Pincode::select('id', 'state')->where('pincode', $marketing_manager->pincode)->first();
            $city  = Pincode::select('id', 'city')->where('pincode', $marketing_manager->pincode)->first();
            $designation = Designation::where('status', 1)->get();
            return view('team_manage.marketing_manager.edit', compact('marketing_manager', 'directors', 'areas', 'state', 'city', 'branch', 'relations', 'designation', 'introducer_id', 'introducer_name'));
        }
        return response()->json(['status' => false, 'message' => 'Marketing Manager not found!']);
    }
    public function update(Request $request, $id)
    {
        $request->validate([
            'reference_code' => 'required',
            'director_id' => 'required',
            'name' => 'required',
            'email' => 'required|email',
            // 'password' => 'required',
            // 'team_name'  => 'required',
            'father_husband_name' => 'required',
            'branch_id' => 'required',
            'join_date' => 'required',
            // 'introduced_by' => 'required',
            'marrital_status' => 'required',
            // 'wedding_date' => 'required',
            'nominee_name' => 'required',
            // 'gender'=>'required',
            'relationship' => 'required',
            'nominee_mobile' => 'required|numeric|digits:10',
             'mobile_no' => 'required|numeric|digits:10',
            'address' => 'required',
            'dob' => 'required|date|before_or_equal:today',
            'designation_id' => 'required',
        ]);
        $data = [];
        if ($request->password) {
            $password = Hash::make($request->password);
            $encrypt_password = encrypt($request->password);
        }
        
        if($request->introduced_by == 'Thired Party')
        {
        //     $validate = $request->validate([
        //     'thired_party_name' => 'required',
        //     'thired_party_mobile' => 'required|numeric|digits:10',
           
        // ]);
            $data['introducer_id'] = 0;
            $data['thired_party_name'] = $request->thired_party_name;
            $data['thired_party_mobile'] = $request->thired_party_mobile;
        }else{
        //     $validate = $request->validate([
        //     'introducer' => 'required',
        //  ]);
        
        if($request->introduced_by != '')
        {
            $data['introducer_id'] = $request->introducer;
        }else{
            
            $data['introducer_id'] = 0;
        }
            $data['thired_party_name'] = null;
            $data['thired_party_mobile'] = null;
        }
        
        //email and mobile_no
        $check_mail = User::where('email', $request->email)->where('id', '!=', $id)->get()->count();
        if ($check_mail > 0) {
            return response()->json(['status' => false, 'message' => 'Email Already Exist!']);
        }

        $check_mobile = User::where('mobile_no', $request->mobile_no)->where('id', '!=', $id)->get()->count();

        if ($check_mobile > 0) {
            return response()->json(['status' => false, 'message' => 'Mobile No Already Exist!']);
        }

        if ($request->introduced_by == 'Thired Party') {
            $data['introducer_id'] = 0;
            $data['thired_party_name'] = $request->thired_party_name;
            $data['thired_party_mobile'] = $request->thired_party_mobile;
        } else {
            $data['introducer_id'] = $request->introducer;
            $data['thired_party_name'] = null;
            $data['thired_party_mobile'] = null;
        }
        $data['reference_code'] = $request->reference_code;

        $data['name'] = $request->name;
        // $data['password'] = $password;
        // $data['encrypt_password'] = $encrypt_password;
        $data['user_type'] = 'marketing-manager';
        $data['director_id'] = $request->director_id;
        $data['designation_id'] = $request->designation_id;
        // $data['team_name'] = $request->team_name;
        $data['father_husband_name'] = $request->father_husband_name;
        $data['branch_id'] = $request->branch_id;
        $data['join_date'] = $request->join_date;
        $data['marrital_status'] = $request->marrital_status;
        $data['email'] = $request->email;
        $data['wedding_date'] = $request->wedding_date;
        $data['nominee_name'] = $request->nominee_name;
        $data['nominee_mobile'] = $request->nominee_mobile;
        $data['address'] = $request->address;
        $data['mobile_no'] = $request->mobile_no;
        $data['alternate_mobile'] = $request->alternate_mobile;
        $data['dob'] = $request->dob;
        $data['gender'] = $request->gender;
        $data['pincode'] = $request->pincode;
        $data['area'] = $request->area;
        $data['city_id'] = $request->city_id;
        $data['state_id'] = $request->state_id;
        $data['country_id'] = $request->country_id;
        $data['bank_name'] = $request->bank_name;
        $data['account_no'] = $request->account_no;
        $data['ifsc_code'] = $request->ifsc_code;
        $data['bank_branch'] = $request->bank_branch;
        $data['introduced_by'] = $request->introduced_by;
        $data['status'] = $request->status;
        $data['relationship'] = $request->relationship;
        $m_manager = User::where('id', $id)->update($data);
        if ($m_manager) {
            return response()->json(['status' => true, 'message' => 'Marketing Manager Updated Successfully!']);
        } else {
            return response()->json(['status' => false, 'message' => 'Marketing Manager Updated Failed!']);
        }
    }
    public function delete($id)
    {
        if (!empty($id)) {
            $marketing_manager = User::where('user_type', 'marketing-manager')->where('id', $id)->delete();
            if ($marketing_manager) {
                return response()->json(['status' => true, 'message' => 'Marketing Manager Deleted Success!']);
            } else {
                return response()->json(['status' => false, 'message' => 'Marketing Manager Deleted Failed!']);
            }
        }
    }
}
