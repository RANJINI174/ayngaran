<?php

namespace App\Http\Controllers;

use App\Models\Branch;
use App\Models\Designation;
use App\Models\Director;
use App\Models\MarketingExecutive;
use App\Models\MarketingManager;
use App\Models\MarketingSupervisor;
use App\Models\Pincode;
use App\Models\Relationship;
use App\Models\Staff_Detail;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class StaffdetailController extends Controller
{
    public function index()
    {
        try {
            // $staff_details = Staff_Detail::leftjoin('branch', 'branch.id', 'staff_details.branch')
            //     ->leftjoin('designation', 'designation.id', 'staff_details.designation')
            //     ->select('staff_details.*', 'designation.designation', 'branch.branch_name')->get();

            $staff_details = User::where('user_type', 'staff')->get();
            return view('staff_details.index', compact('staff_details'));
        } catch (\Exception $e) {
            return back()->with(['error' => $e->getMessage()])->withInput();
        }
    }
    public function create()
    {
        try {
            $count = User::where('user_type', 'staff')->get()->count();
            $branch = Branch::where('status', 1)->get();
            $relations = Relationship::where('status', 1)->get();
            $designation = Designation::where('status', 1)->get();
            return view('staff_details.add', compact('count', 'branch', 'relations', 'designation'));
        } catch (\Exception $e) {
            return back()->with(['error' => $e->getMessage()])->withInput();
        }
    }
    public function store(Request $request)
    {
        $request->validate([
            'reference_code' => 'required',
            'name' => 'required',
            'password' => 'required',
            'father_husband_name' => 'required',
            'branch_id' => 'required',
            'join_date' => 'required',
            'introduced_by' => 'required',
            'marrital_status' => 'required',
            // 'wedding_date' => 'required',
            'nominee_name' => 'required',
            'relationship' => 'required',
            'nominee_mobile' => 'required|numeric|digits:10',
            'designation_id' => 'required',
            'mobile_no' => 'required|numeric|digits:10',
            'address' => 'required',
            'dob' => 'required|date|before_or_equal:today',
            // 'gender' => 'required',
        ], [
            'branch_id.required' => 'The branch field is required.',
            'designation_id.required' => 'The designation field is required',
        ]);
        if ($request->email != "") {
            $request->validate([
                'email' => 'email'
            ]);
        }
        if ($request->introduced_by == 'Thired Party') {
            $validate = $request->validate([
                'thired_party_name' => 'required',
                'thired_party_mobile' => 'required|numeric|digits:10',

            ]);
        } else {
            $validate = $request->validate([
                'introducer' => 'required',

            ]);
        }

        if ($request->password) {
            $password = Hash::make($request->password);
            $encrypt_password = encrypt($request->password);
        }
        //email and mobile_no
        $check_mail = User::where('email', $request->email)->get()->count();
        if ($check_mail > 0) {
            return response()->json(['status' => false, 'message' => 'Email Already Exist!']);
        }

        $check_mobile = User::where('mobile_no', $request->mobile_no)->get()->count();

        if ($check_mobile > 0) {
            return response()->json(['status' => false, 'message' => 'Mobile No Already Exist!']);
        }


        $staff = new User();
        $staff->reference_code = $request->reference_code;
        $staff->name = $request->name;
        $staff->password = $password;
        $staff->encrypt_password = $encrypt_password;
        $staff->user_type = 'staff';
        $staff->designation_id = $request->designation_id;
        // $staff->team_name = $request->team_name;
        $staff->father_husband_name = $request->father_husband_name;
        $staff->branch_id = $request->branch_id;
        $staff->join_date = $request->join_date;
        $staff->marrital_status = $request->marrital_status;
        $staff->email = $request->email;
        $staff->wedding_date = $request->wedding_date;
        $staff->nominee_name = $request->nominee_name;
        $staff->nominee_mobile = $request->nominee_mobile;
        $staff->relationship = $request->relationship;
        $staff->address = $request->address;
        $staff->mobile_no = $request->mobile_no;
        $staff->alternate_mobile = $request->alternate_mobile;
        $staff->dob = $request->dob;
        $staff->gender = $request->gender;
        $staff->pincode = $request->pincode;
        $staff->area = $request->area;
        $staff->city_id = $request->city_id;
        $staff->state_id = $request->state_id;
        $staff->country_id = $request->country_id;
        $staff->bank_name = $request->bank_name;
        $staff->account_no = $request->account_no;
        $staff->ifsc_code = $request->ifsc_code;
        $staff->bank_branch = $request->bank_branch;
        $staff->introduced_by = $request->introduced_by;
        $staff->introducer_id = $request->introducer;
        $staff->thired_party_name = $request->thired_party_name;
        $staff->thired_party_mobile = $request->thired_party_mobile;

        $insert =  $staff->save();

        if ($insert) {
            return response()->json(['status' => true, 'message' => 'Staff Created Successfully!']);
        } else {
            return response()->json(['status' => false, 'message' => 'Staff Creation Failed!']);
        }
    }

    public function edit($id)
    {
        if (!empty($id)) {
            $introducer_name = '';
            $introducer_id = '';
            $staff = User::where('user_type', 'staff')->where('id', $id)->first();
            if ($staff->introducer_by != 'thired_party') {
                $introducer_name = User::where('designation_id', $staff->introduced_by)->get();
                $introducer_id = User::where('id', $staff->introducer_id)->value('reference_code');
            }

            $branch = Branch::where('status', 1)->get();
            $relations = Relationship::where('status', 1)->get();
            $areas  = Pincode::where('pincode', $staff->pincode)->get();
            $state  = Pincode::select('id', 'state')->where('pincode', $staff->pincode)->first();
            $city  = Pincode::select('id', 'city')->where('pincode', $staff->pincode)->first();
            $designation = Designation::where('status', 1)->get();

            return view('staff_details.edit', compact('staff', 'areas', 'state', 'city', 'branch', 'relations', 'designation', 'introducer_id', 'introducer_name'));
        }
    }
    public function update(Request $request, $id)
    {
        $request->validate([
            'reference_code' => 'required',
            'name' => 'required',
            'father_husband_name' => 'required',
            'branch_id' => 'required',
            'join_date' => 'required',
            'introduced_by' => 'required',
            'marrital_status' => 'required',
            // 'wedding_date' => 'required',
            'nominee_name' => 'required',
            'relationship' => 'required',
            'nominee_mobile' => 'required|numeric|digits:10',
            'designation_id' => 'required',
            'mobile_no' => 'required|numeric|digits:10',
            'address' => 'required',
            'dob' => 'required|date|before_or_equal:today',
            // 'gender' => 'required',
        ], [
            'branch_id.required' => 'The branch field is required.',
            'designation_id.required' => 'The designation field is required',
        ]);
        if ($request->email != "") {
            $request->validate([
                'email' => 'email'
            ]);
        }
        $data = [];
        if ($request->password) {
            $password = Hash::make($request->password);
            $encrypt_password = encrypt($request->password);
        }

        if ($request->introduced_by == 'Thired Party') {
            $validate = $request->validate([
                'thired_party_name' => 'required',
                'thired_party_mobile' => 'required|numeric|digits:10',

            ]);

            $data['introducer_id'] = 0;
            $data['thired_party_name'] = $request->thired_party_name;
            $data['thired_party_mobile'] = $request->thired_party_mobile;
        } else {
            $validate = $request->validate([
                'introducer' => 'required',
            ]);
            $data['introducer_id'] = $request->introducer;
            $data['thired_party_name'] = null;
            $data['thired_party_mobile'] = null;
        }
        //email and mobile_no
        $check_mail = User::where('email', $request->email)->where('id', '!=', $id)->get()->count();
        if ($check_mail > 0) {
            return response()->json(['status' => false, 'message' => 'Email Already Exist!']);
        }

        $check_mobile = User::where('mobile_no', $request->mobile_no)->where('id', '!=', $id)->get()->count();

        if ($check_mobile > 0) {
            return response()->json(['status' => false, 'message' => 'Mobile No Already Exist!']);
        }

        if ($request->introduced_by == 'Thired Party') {
            $data['introducer_id'] = 0;
            $data['thired_party_name'] = $request->thired_party_name;
            $data['thired_party_mobile'] = $request->thired_party_mobile;
        } else {
            $data['introducer_id'] = $request->introducer;
            $data['thired_party_name'] = null;
            $data['thired_party_mobile'] = null;
        }
        $data['reference_code'] = $request->reference_code;
        $data['name'] = $request->name;
        // $data['password'] = $password;
        // $data['encrypt_password'] = $encrypt_password;
        $data['user_type'] = 'staff';
        $data['designation_id'] = $request->designation_id;
        // $staff->team_name = $request->team_name;
        $data['father_husband_name'] = $request->father_husband_name;
        $data['branch_id'] = $request->branch_id;
        $data['join_date'] = $request->join_date;
        $data['marrital_status'] = $request->marrital_status;
        $data['email'] = $request->email;
        $data['wedding_date'] = $request->wedding_date;
        $data['nominee_name'] = $request->nominee_name;
        $data['nominee_mobile'] = $request->nominee_mobile;
        $data['relationship'] = $request->relationship;
        $data['address'] = $request->address;
        $data['mobile_no'] = $request->mobile_no;
        $data['alternate_mobile'] = $request->alternate_mobile;
        $data['dob'] = $request->dob;
        $data['gender'] = $request->gender;
        $data['pincode'] = $request->pincode;
        $data['area'] = $request->area;
        $data['city_id'] = $request->city_id;
        $data['state_id'] = $request->state_id;
        $data['country_id'] = $request->country_id;
        $data['bank_name'] = $request->bank_name;
        $data['account_no'] = $request->account_no;
        $data['ifsc_code'] = $request->ifsc_code;
        $data['bank_branch'] = $request->bank_branch;
        $data['introduced_by'] = $request->introduced_by;
        $data['thired_party_name'] = $request->thired_party_name;
        $data['thired_party_mobile'] = $request->thired_party_mobile;
        $update = User::where('id', $id)->update($data);
        if ($update) {
            return response()->json(['status' => true, 'message' => 'Staff Updated Successfully!']);
        } else {
            return response()->json(['status' => false, 'message' => 'Staff Updated Failed!']);
        }
    }
    public function delete($id)
    {
        if (!empty($id)) {
            $staff = User::where('user_type', 'staff')->where('id', $id)->delete();
            if ($staff) {
                return response()->json(['status' => true, 'message' => 'Staff Deleted Success!']);
            } else {
                return response()->json(['status' => false, 'message' => 'Staff Manager Deleted Failed!']);
            }
        }
    }
}